// 提货预约协同小程序 v2 —— 全局入口 + 数据中心（深色驾驶舱版）
const STORE_KEY = 'warehouse_reserve_store_v2';

// 需求单状态
const DEMAND_STATUS = {
  pending: { text: '待预约', color: '#f59e0b' },
  reserved: { text: '已预约', color: '#3b82f6' },
  done: { text: '已提货', color: '#34d399' }
};

// 预约单状态
const RESERVE_STATUS = {
  pending: { text: '待审核', color: '#f59e0b' },
  approved: { text: '已派月台', color: '#3b82f6' },
  loading: { text: '备货中', color: '#a78bfa' },
  ready: { text: '备货完成', color: '#22d3ee' },
  done: { text: '已提货', color: '#34d399' }
};

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}
function nowTime() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function initMock() {
  const t = nowTime();
  const d = today();
  return {
    seq: 20,
    dockList: ['月台 1', '月台 2', '月台 3', '月台 4', '冷链月台 1', '冷链月台 2'],
    categories: ['工业原料', '包装耗材', '食品饮料', '冷链生鲜', '电子数码'],
    demands: [
      {
        id: 'D001', product: '工业润滑油 200L桶', category: '工业原料', qty: '1200', unit: 'L',
        lot: 'A-01', customer: '华南商贸有限公司', logistics: '顺捷物流',
        urgent: false, window: '09:30-11:30', note: '桶装摆放，需叉车作业',
        status: 'reserved', createTime: t, date: d
      },
      {
        id: 'D002', product: '包装纸箱 60×40×40', category: '包装耗材', qty: '5000', unit: '只',
        lot: 'B-03', customer: '汇通包装连锁', logistics: '安达货运',
        urgent: true, window: '11:00-12:00', note: '',
        status: 'reserved', createTime: t, date: d
      },
      {
        id: 'D003', product: '面粉 25kg/袋', category: '食品饮料', qty: '800', unit: '袋',
        lot: 'C-02', customer: '金穗食品', logistics: '顺捷物流',
        urgent: false, window: '13:00-15:00', note: '防潮，请勿叠高超过8层',
        status: 'pending', createTime: t, date: d
      },
      {
        id: 'D004', product: '冷冻肉品 10kg/箱', category: '冷链生鲜', qty: '300', unit: '箱',
        lot: '冷链1区', customer: '每日鲜生鲜', logistics: '安达货运',
        urgent: false, window: '07:30-08:30', note: '',
        status: 'done', createTime: t, date: d
      }
    ],
    reservations: [
      {
        id: 'R001', demandId: 'D001', eta: '09:30', plate: '鲁A·8K231',
        driver: '王师傅', phone: '138****5201', qty: '1200L', dock: '月台 2',
        status: 'ready',
        track: [
          { time: t, text: '提交提货预约（预计到达 09:30）' },
          { time: t, text: '仓库审核通过，分配月台 2' },
          { time: t, text: '开始备货' },
          { time: t, text: '备货完成，等待车辆到厂' }
        ]
      },
      {
        id: 'R002', demandId: 'D002', eta: '11:00', plate: '鲁H·3T779',
        driver: '李师傅', phone: '139****3320', qty: '5000只', dock: '',
        status: 'pending', track: [{ time: t, text: '提交提货预约（预计到达 11:00）' }]
      },
      {
        id: 'R003', demandId: 'D001', eta: '', plate: '', driver: '', phone: '', qty: '', dock: '',
        status: '', track: [], _empty: true
      },
      {
        id: 'R004', demandId: 'D004', eta: '07:40', plate: '鲁B·6M015',
        driver: '赵师傅', phone: '188****9012', qty: '300箱', dock: '冷链月台 1',
        status: 'done',
        track: [
          { time: t, text: '提交提货预约（预计到达 07:40）' },
          { time: t, text: '仓库审核通过，分配冷链月台 1' },
          { time: t, text: '开始备货' },
          { time: t, text: '备货完成，等待车辆到厂' },
          { time: t, text: '车辆到厂提货完成，顺利离场' }
        ]
      }
    ],
    vehicles: [
      { plate: '鲁A·8K231', driver: '王师傅', phone: '138****5201', type: '重型厢式' },
      { plate: '鲁H·3T779', driver: '李师傅', phone: '139****3320', type: '平板车' },
      { plate: '鲁B·6M015', driver: '赵师傅', phone: '188****9012', type: '冷链车' }
    ],
    messages: [
      { id: 'M1', type: 'reserve', title: '预约提交成功', text: 'R002 已提交提货预约，等待仓库审核', time: t, read: false },
      { id: 'M2', type: 'dock', title: '月台分配完成', text: 'R001 已通过审核并分配月台 2', time: t, read: false },
      { id: 'M3', type: 'notice', title: '备货完成提醒', text: 'R001 备货完成，等待车辆到厂', time: t, read: true }
    ]
  };
}

App({
  globalData: {
    store: null,
    statusMap: { demand: DEMAND_STATUS, reserve: RESERVE_STATUS },
    now: nowTime,
    today
  },

  onLaunch() {
    let store = null;
    try {
      store = wx.getStorageSync(STORE_KEY);
    } catch (e) {
      store = null;
    }
    if (!store || !store.demands) {
      store = initMock();
      wx.setStorageSync(STORE_KEY, store);
    }
    this.globalData.store = store;
  },

  getStore() {
    if (!this.globalData.store) {
      this.onLaunch();
    }
    return this.globalData.store;
  },

  save() {
    try {
      wx.setStorageSync(STORE_KEY, this.globalData.store);
    } catch (e) {
      // 忽略
    }
  },

  reset() {
    this.globalData.store = initMock();
    wx.setStorageSync(STORE_KEY, this.globalData.store);
  },

  nextId(prefix) {
    const store = this.getStore();
    store.seq += 1;
    return prefix + (store.seq < 10 ? '00' + store.seq : '0' + store.seq);
  },

  // 写入站内消息
  pushMessage(type, title, text) {
    const store = this.getStore();
    store.messages.unshift({ id: this.nextId('M'), type, title, text, time: nowTime(), read: false });
    this.save();
  },

  markAllRead() {
    const store = this.getStore();
    store.messages.forEach((m) => (m.read = true));
    this.save();
  },

  unreadCount() {
    return this.getStore().messages.filter((m) => !m.read).length;
  }
});
