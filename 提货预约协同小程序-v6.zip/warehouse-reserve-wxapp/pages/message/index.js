const ICONS = require('../../utils/icons.js');
const app = getApp();

Page({
  data: {
    icons: ICONS,
    list: []
  },

  onShow() {
    const list = app.getStore().messages.slice().reverse();
    this.setData({ list });
  },

  readAll() {
    app.markAllRead();
    wx.showToast({ title: '已全部标记为已读', icon: 'none' });
    const list = app.getStore().messages.slice().reverse();
    this.setData({ list });
  },

  resetData() {
    wx.showModal({
      title: '重置演示数据',
      content: '将清空所有操作记录，恢复初始协同演示数据。该操作不可恢复，确认继续？',
      confirmColor: '#f87171',
      success: (res) => {
        if (!res.confirm) return;
        wx.removeStorageSync('wr_store');
        app.initMock();
        app.save();
        wx.showToast({ title: '已重置为初始演示状态', icon: 'none' });
        this.setData({ list: app.getStore().messages.slice().reverse() });
      }
    });
  }
});
